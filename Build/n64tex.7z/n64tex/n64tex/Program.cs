﻿using System;
using System.IO;
using System.Drawing;

namespace n64tex {
	class Program {
		static void Main(string[] args) {
			foreach (String arg in args) {
				if (File.Exists(Path.GetDirectoryName(arg) + "\\" + Path.GetFileName(arg))) {
					Bitmap thePNG = new Bitmap(Path.GetDirectoryName(arg) + "\\" + Path.GetFileName(arg));
					UInt16[] RGBA5551Data = new UInt16[thePNG.Height * thePNG.Width];
					for (var h = 0; h < thePNG.Height; h++) {
						for (var w = 0; w < thePNG.Width; w++) {
							Color pixel = thePNG.GetPixel(w, h);
							int red = pixel.R / 8 * 0x0800;
							int green = pixel.G / 8 * 0x0040;
							int blue = pixel.B / 8 * 0x0002;
							int alpha = pixel.A > 0 ? 1 : 0;
							RGBA5551Data[h * thePNG.Width + w] = (UInt16)(red + green + blue + alpha);
						}
					}
					try {
						// Delete the file if it exists.
						string newFileName = Path.GetDirectoryName(arg) + "\\" + Path.GetFileNameWithoutExtension(arg) + ".rgba5551";
						if (File.Exists(newFileName)) {
							File.Delete(newFileName);
						}

						// Create the file.
						using (FileStream fs = File.Create(newFileName)) {
							using (var writer = new BinaryWriter(fs)) {
								foreach (UInt16 item in RGBA5551Data) {
									if (BitConverter.IsLittleEndian) {
										var output = BitConverter.GetBytes(item);
										Array.Reverse(output);
										writer.Write(output);
									} else {
										writer.Write(item);
									}
								}
							}
						}
					} catch (Exception ex) {
						Console.WriteLine(ex.ToString());
					}
				} else {
					Console.WriteLine("The file " + arg + " does not exist");
				}
			}
		}
	}
}
